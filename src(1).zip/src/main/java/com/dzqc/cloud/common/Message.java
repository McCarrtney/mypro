package com.dzqc.cloud.common;

public interface Message {

	String SERVER_ERROR = "服务器错误";
	
}
