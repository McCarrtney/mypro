package com.dzqc.cloud.service;

import com.dzqc.cloud.entity.Departmentinfo;

import java.util.List;

public interface DepartmentinfoService {

    public List<Departmentinfo> selectAll();


}
