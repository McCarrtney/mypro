package com.dzqc.cloud.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserinfoControllerTest {

    @Test
    void login() {
    }

    @Test
    void register() {
    }
}